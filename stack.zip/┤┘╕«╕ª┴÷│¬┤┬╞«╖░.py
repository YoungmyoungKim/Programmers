def solution_1(bridge_length, weight, truck_weights):
    answer = 0
    passing=[]
    passed=[]
    trucks=[x for x in truck_weights]
    on_t=[0 for x in truck_weights]
    while(len(passed)<len(truck_weights)):
        if len(trucks)!=0:
            if sum(passing)+trucks[0]<=weight:
                passing.append(trucks[0])
                del trucks[0]
        print(passing)

        for i in range(len(passing)):
            if on_t[i]>=bridge_length:
                passed.append(passing[i])
                del passing[i]
            on_t[i]+=1
        answer=answer+1
        #print(on_t)
        #print(passed)

    #print(on_t)
    #print(passing)
    #print(passed)
    return answer

def solution_2(bridge_length, weight, truck_weights):
    answer = 0
    passed=[]
    passing=[0 for x in range(bridge_length)]
    trucks=[x for x in truck_weights]
    while(len(passed)<len(truck_weights)):
        if len(trucks)!=0 and sum(passing)+trucks[0]<=weight:
            passing.append(trucks[0])
            del trucks[0]
        else:
            passing.append(0)
        if passing[0]!=0:
            passed.append(passing[0])
        del passing[0]
        answer+=1
        print('passed:'+str(passed)+'passing:'+str(passing))
        #print('passed:'+str(passed))
    #answer=answer-2
    return answer

def solution_3(bridge_length, weight, truck_weights):
    answer = 0
    passed=[]
    passing=[0 for x in range(bridge_length)]
    trucks=[x for x in truck_weights]
    while(len(passed)<len(truck_weights)):
        if len(passing)>bridge_length:
            if passing[0]!=0:
                passed.append(passing[0])
            del passing[0]

        if len(trucks)!=0 and sum(passing)+trucks[0]<=weight:
            passing.append(trucks[0])
            del trucks[0]
        else:
            passing.append(0)
        answer+=1
        print('passed:'+str(passed)+'passing:'+str(passing))
        #print('passed:'+str(passed))
    #answer=answer-2
    return answer

def solution_4(bridge_length, weight, truck_weights):
    answer = 0
    passed=[]
    passing=[0 for x in range(bridge_length)]
    trucks=[x for x in truck_weights]
    while(len(passed)<len(truck_weights)):
        if len(trucks)!=0 and sum(passing)+trucks[0]<=weight:
            passing.append(trucks[0])
            del trucks[0]
        else:
            passing.append(0)

        if len(passing)>bridge_length:
            if passing[0]!=0:
                passed.append(passing[0])
            del passing[0]

        answer+=1
        print('passed:'+str(passed)+'passing:'+str(passing))

    #answer=answer-2
    return answer

b1, w1, t_w1=2, 10, [7,4,5,6]
b2, w2, t_w2=100, 100, [10]
b3, w3, t_w3=100, 100, [10,10,10,10,10,10,10,10,10,10]

print(solution_4(b1, w1, t_w1))
#print(solution_4(b2, w2, t_w2))
#print(solution_2(b3, w3, t_w3))
